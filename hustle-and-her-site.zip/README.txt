HUSTLE & HER WEBSITE STARTER

Upload these files to Cloudflare Pages.

Required image filenames:
hero.jpg
self-defense.jpg
rolling-tray.jpg
hoodie.jpg
accessories.jpg

Pages:
index.html = homepage
products.html = full shop page
product.html = single product page
checkout.html = checkout mockup page
program.html = program / starter bundle page

IMPORTANT:
The checkout page is only a visual mockup. To accept real payments, connect a payment processor like PayPal, Stripe, Square, Shopify Buy Button, etc.
